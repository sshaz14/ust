from pymongo import MongoClient

#mongo_url = "localhost:27017"
mongo_url = "mongodb+srv://sshaz79:aOLyCa8T6M0HmLUW@cluster0.zxrm4gr.mongodb.net/?retryWrites=true&w=majority"

client = MongoClient(mongo_url)
db = client.blog
